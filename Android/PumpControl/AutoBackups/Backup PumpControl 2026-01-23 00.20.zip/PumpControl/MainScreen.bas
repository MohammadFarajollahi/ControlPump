﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Activity
Version=13.1
@EndOfDesignText@
#Region  Activity Attributes 
	#FullScreen: False
	#IncludeTitle: false
#End Region

Sub Process_Globals
	Dim Serial1 As Serial
	Dim AStream As AsyncStreams
	Dim DeviceList As List

End Sub

Sub Globals
	Dim BufferString As String = ""   ' <--
	Dim bmp As BitmapDrawable

	Private Panel1 As Panel
	Private Button2 As Button
	Private Close As Button
	Private lstDevices As ListView
	Private Button1 As Button
	Private ImageView1 As ImageView
End Sub

Sub Activity_Create(FirstTime As Boolean)
	Activity.LoadLayout("MainScreen")
	Panel1.Visible = False
	Serial1.Initialize("Serial1")
	DeviceList.Initialize
End Sub

Sub Activity_Resume

End Sub

Sub Activity_Pause (UserClosed As Boolean)

End Sub


Private Sub Button2_Click
	
End Sub

Private Sub Close_Click
	Panel1.Visible = False
End Sub


'اتصال به بلوتوث
Private Sub Button1_Click
	Panel1.Visible = True
	If Serial1.IsEnabled = False Then
		ToastMessageShow("Bluetooth روشن نیست!", True)
		Return
	End If
    
	Dim PairedDevices As Map
	PairedDevices = Serial1.GetPairedDevices
	lstDevices.Clear
    
	For i = 0 To PairedDevices.Size - 1
		Dim name As String = PairedDevices.GetKeyAt(i)
		Dim mac As String = PairedDevices.GetValueAt(i)
		lstDevices.AddSingleLine2(name, mac)
	Next
    
	ToastMessageShow("لیست دستگاه‌ها آماده است", False)
End Sub

Sub lstDevices_ItemClick (Position As Int, Value As Object)
	Dim MacAddress As String = Value
	Serial1.Connect(MacAddress)   ' اتصال به ماژول انتخاب شده
	ToastMessageShow("در حال اتصال...", False)
End Sub

Sub Serial1_Connected (Success As Boolean)
	If Success Then
		ToastMessageShow("اتصال موفق!", False)
		AStream.Initialize(Serial1.InputStream, Serial1.OutputStream, "AStream")
		bmp.Initialize(LoadBitmap(File.DirAssets, "connected_500px.png"))
		ImageView1.Background = bmp
		Dim ss As String
		ss= "GetEeprom"
		Dim data() As Byte = ss.GetBytes("UTF8")'txtData.Text.GetBytes("UTF8")
		AStream.Write(data)
	Else
		ToastMessageShow("اتصال ناموفق!", True)
	End If
End Sub

Sub AStream_NewData (Buffer() As Byte)
	
	Dim msg As String = BytesToString(Buffer, 0, Buffer.Length, "UTF8")
	BufferString = BufferString & msg   ' تکه جدید رو به بافر اضافه کن
	
	If BufferString.Contains(Chr(10)) Then
	'	EditText14.Text =BufferString
		Dim lines() As String = Regex.Split(Chr(10), BufferString)
		For i = 0 To lines.Length - 1
			Dim line As String = lines(i).Trim
			'If line.Length > 0 Then ParseEEPROMData(line)
		Next
		BufferString = lines(lines.Length - 1)
		BufferString = ""
	End If
End Sub

